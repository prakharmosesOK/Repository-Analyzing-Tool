import os
# os: This module provides a portable way to use operating system-dependent functionality.
# It provides a way to interact with the computer's file system.

import math
"""
math: This module provides fast and easy way to use all the math functionalities.
It provides a way to execute complex math function with just a function.
"""

# Python 3 code to find sum
# of elements in given array
def sum_of_array(arr):
  """
  This function finds the sum of elements in a given array.

  Args:
    arr (list): The array whose elements are to be summed.

  Returns:
    int: The sum of the elements in the array.
  """

  sum = 0
  for i in range(len(arr)):
    sum += arr[i]
  return sum

def sum(arr):

    """
    This function finds the sum of elements in a given array.

    Args:
        arr (list): The array whose elements are to be summed.

    Returns:
        int: The sum of the elements in the array.
    """

    # initialize a variable
    # to store the sum
    # while iterating through
    # the array later
    sum = 0

    # iterate through the array
    # and add each element to the sum variable
    # one at a time
    for i in arr:
        sum = sum + i

    return(sum)

# main function
if __name__ == "__main__":
    """
    This is the main function that calls the _sum() function to calculate the sum of elements in a given array.
    """

    # input values to list
    arr = [12, 3, 4, 15]

    # calculating length of array
    n = len(arr)
    # calling function ans store the sum in ans
    ans = sum(arr)
    # display sum
    print('Sum of the array is ', ans)
